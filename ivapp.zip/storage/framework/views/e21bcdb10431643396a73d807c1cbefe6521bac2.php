
  <?php $__env->startSection('style'); ?>
    <style type="text/css">
      
    </style>
  <?php $__env->stopSection(); ?> 
<?php $__env->startSection('content'); ?>

        <ul class="breadcrumb">
            <li><a href="">User</a></li>
            <li><a href="">Edit User</a></li>
        </ul>
        
        <div class="page-title">                    
            <h2><span class="fa fa-arrow-circle-o-left"></span> Edit User</h2>
        </div>

         <div class="page-content-wrap">
            <div class="row">
                <div class="col-md-12">

                  
                      
                          <div class="panel panel-default">
                             <div class="panel-heading">
                                <h3 class="panel-title"> Edit User</h3>
                             </div>

                             <form class="form-horizontal" method="post" action="<?php echo e(url('admin/user/edit/'.$getrecord->id)); ?>" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>



                             <div class="panel-body">
                               
                               <div class="form-group">
                                  <label class="col-md-3 col-xs-12 control-label">Name <span style="color:red"> *</span></label>
                                   <div class="col-md-7 col-xs-12">
                                      <div class="">
                                         <input name="name" maxlength="50" value="<?php echo e($getrecord->name); ?>" placeholder="Name" type="text" required class="form-control" />
                                         <span style="color:red"><?php echo e($errors->first('name')); ?></span>
                                      </div>
                                   </div>
                                </div>

                                 
                                 <div class="form-group">
                                  <label class="col-md-3 col-xs-12 control-label">Email ID <span style="color:red"> *</span></label>
                                   <div class="col-md-7 col-xs-12">
                                      <div class="">
                                         <input name="email" readonly value="<?php echo e($getrecord->email); ?>" placeholder="Email ID" type="email" class="form-control" />
                                         <span style="color:red"><?php echo e($errors->first('email')); ?></span>
                                      </div>
                                   </div>
                                </div>

                               
                             
                              
                               <div class="form-group">
                                   <label class="col-md-3 col-xs-12 control-label">Password <span style="color:red"> </span></label>
                                   <div class="col-md-7 col-xs-12">
                                      <div class="">
                                         <input name="password" value="" placeholder="Password" type="text" class="form-control" />
                                           <span style="color:red"><?php echo e($errors->first('password')); ?></span>
                                             (Leave blank if you are not changing the password)
                                      </div>
                                   </div>
                                </div>
                            
                              </div>
                             <div class="panel-footer">
                                <button class="btn btn-primary pull-right">Update</button>
                             </div>

                            </form>

                          </div>
                      
                    


                </div>
            </div>
        </div>
 
<?php $__env->stopSection(); ?>
  <?php $__env->startSection('script'); ?>
  <script type="text/javascript">
   
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\ivapp\resources\views/backend/user/edit.blade.php ENDPATH**/ ?>