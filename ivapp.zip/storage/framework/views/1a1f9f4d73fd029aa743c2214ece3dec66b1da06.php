

<?php $__env->startSection('style'); ?>
	<style type="text/css">
	
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <ul class="breadcrumb">
            <li><a href="">Product</a></li>
            <li><a href="">Product List</a></li>
        </ul>
        
        <div class="page-title">                    
            <h2><span class="fa fa-arrow-circle-o-left"></span> Product List</h2>
        </div>
         <div class="page-content-wrap">
            <div class="row">
                <div class="col-md-12">

                    
                   <?php echo $__env->make('_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                 <a href="<?php echo e(url('admin/product/import')); ?>" class="btn btn-primary" title="Import Excel"><i class="fa fa-upload"></i>&nbsp;&nbsp;<span class="bold">Import Excel</span></a> 
                

                    
            <div class="panel panel-default">
                  <div class="panel-heading">
                      <h3 class="panel-title">Product Search</h3>
                  </div>

                  <div class="panel-body" style="overflow: auto;">
                    <form action="" method="get">
                        <div class="col-md-4">
                           <label>ID</label>
                           <input type="text" value="<?php echo e(Request()->idsss); ?>" class="form-control" placeholder="ID" name="idsss">
                        </div>
                        <div class="col-md-4">
                           <label>Sheet No</label>
                           <input type="text" class="form-control" value="<?php echo e(Request()->sheet_no); ?>" placeholder="Sheet No" name="sheet_no">
                        </div>
                    
                       
                        <div class="col-md-4">
                           <label>Location</label>
                           <input type="text" class="form-control" value="<?php echo e(Request()->location); ?>" placeholder="Location" name="location">
                        </div>
                      
                        
                        <div style="clear: both;"></div>
                        <br>
                        <div class="col-md-12">
                           <input type="submit" class="btn btn-primary" value="Search">
                           <a href="<?php echo e(url('admin/product')); ?>" class="btn btn-success">Reset</a>
                        </div>
                     </form>
                  </div>
               </div>  

                    

                    
              <div class="panel panel-default">
                  <div class="panel-heading">
                      <h3 class="panel-title">Product List</h3>
                  </div>
                 

              <div class="panel-body" style="overflow: auto;">
                  <table  class="table table-striped table-bordered table-hover">
                      <thead>
                          <tr>
                              <th>ID</th>
                              <th>Sheet No</th>
                              <th>Date</th>
                              <th>Location</th>
                              <th>Sub Location</th>
                              <th>Asset</th>
                              <th>Qty</th>
                              <th>Action</th>
                          </tr>
                      </thead>
                      <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $getrecord; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                          <tr>
                              <td><?php echo e($value->id); ?></td>
                              <td><?php echo e($value->name); ?></td>
                              <td><?php echo e($value->email); ?></td>                        
                              
                              <td>
                                
                                 <a href="<?php echo e(url('admin/product/edit/'.$value->id)); ?>" class="btn btn-success btn-rounded btn-sm"><span class="fa fa-pencil"></span></a> 
                        
                            

     						           <button class="btn btn-danger btn-rounded btn-sm" onClick="delete_record('<?php echo e(url('admin/product/delete/'.$value->id)); ?>');"><span class="fa fa-trash-o"></span></button> 
                   


                               <!-- MESSAGE BOX-->
     
                    <!-- END MESSAGE BOX-->    


                              </td>
                          </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                          <tr>
                              <td colspan="100%">Record not found.</td>

                          </tr>
                          <?php endif; ?>
                      </tbody>

                  </table>
                 <div style="float: right">
                   
                     
                    <?php echo e($getrecord->links()); ?> 
                
                  </div>
              </div>

              </div>
              
                    
                </div>
            </div>
        </div>


<?php $__env->stopSection(); ?>
  <?php $__env->startSection('script'); ?>
  <script type="text/javascript">
  
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\ivapp\resources\views/backend/product/list.blade.php ENDPATH**/ ?>