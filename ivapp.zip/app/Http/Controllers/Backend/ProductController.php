<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Product;
use App\Imports\ProductImport;

use Maatwebsite\Excel\Facades\Excel;
use Hash;
use DB;

class ProductController extends Controller
{
    
    public function product_index(Request $request)
    {
        $getrecord = Product::orderBy('id', 'desc');

        $getrecord = $getrecord->paginate(40);
        $data['getrecord'] = $getrecord;

        $data['meta_title'] = 'Product List';
        return view('backend.product.list', $data);
    }

    public function product_add_import(){
         $data['meta_title'] = 'Import Excel';
        return view('backend.product.add_excel', $data);
    }

    public function product_store_import() 

    {

        Excel::import(new ProductImport,request()->file('file'));

             

        return back();

    }
}