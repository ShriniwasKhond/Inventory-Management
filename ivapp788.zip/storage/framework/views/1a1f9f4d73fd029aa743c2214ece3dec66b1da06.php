

<?php $__env->startSection('style'); ?>
	<style type="text/css">
	
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <ul class="breadcrumb">
            <li><a href="">Product</a></li>
            <li><a href="">Product List</a></li>
        </ul>
        
        <div class="page-title">                    
            <h2><span class="fa fa-arrow-circle-o-left"></span> Product List</h2>
        </div>
         <div class="page-content-wrap">
            <div class="row">
                <div class="col-md-12">

                    
                   <?php echo $__env->make('_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                <a href="<?php echo e(url('admin/product/add')); ?>" class="btn btn-primary" title="Add New Product"><i class="fa fa-plus"></i>&nbsp;&nbsp;<span class="bold">Add New Product</span></a>  
                 <a href="<?php echo e(url('admin/product/import')); ?>" class="btn btn-primary" title="Import Excel"><i class="fa fa-upload"></i>&nbsp;&nbsp;<span class="bold">Import Excel</span></a> 
                

                    
            <div class="panel panel-default">
                  <div class="panel-heading">
                      <h3 class="panel-title">Product Search</h3>
                  </div>

                  <div class="panel-body" style="overflow: auto;">
                    <form action="" method="get">
                        <div class="col-md-2">
                           <label>ID</label>
                           <input type="text" value="<?php echo e(Request()->idsss); ?>" class="form-control" placeholder="ID" name="idsss">
                        </div>
                        <div class="col-md-3">
                           <label>Sheet No</label>
                           <input type="number" class="form-control" value="<?php echo e(Request()->sheet_no); ?>" placeholder="Sheet No" name="sheet_no">
                        </div>
                        <div class="col-md-2">
                           <label>Date</label>
                           <input type="date" class="form-control" value="<?php echo e(Request()->product_date); ?>" placeholder="Date" name="product_date">
                        </div>
                    
                       
                        <div class="col-md-3">
                           <label>Location</label>
                           <input type="text" class="form-control" value="<?php echo e(Request()->location); ?>" placeholder="Location" name="location">
                        </div>

                         <div class="col-md-2">
                           <label>Qty</label>
                           <input type="number" class="form-control" value="<?php echo e(Request()->qty); ?>" placeholder="Qty" name="qty">
                        </div>
                      
                        
                        <div style="clear: both;"></div>
                        <br>
                        <div class="col-md-12">
                           <input type="submit" class="btn btn-primary" value="Search">
                           <a href="<?php echo e(url('admin/product')); ?>" class="btn btn-success">Reset</a>
                        </div>
                     </form>
                  </div>
               </div>  

                    

                    
              <div class="panel panel-default">
                  <div class="panel-heading">
                      <h3 class="panel-title">Product List</h3>
                      <a href="" class="btn btn-danger"  onclick="return confirm('Are you sure you want to delete?');" id="getDeleteURL" style="float: right;">Delete</a>
                  </div>
                 

              <div class="panel-body" style="overflow: auto;">
                  <table  class="table table-striped table-bordered table-hover">
                      <thead>
                          <tr>
                             <th>#</th>
                              <th>ID</th>
                             
                              <th>Sheet No</th>
                              <th>Date</th>
                              <th>Location</th>
                              <th>Sub Location</th>
                              <th>Asset</th>
                              <th>Qty</th>
                              <th>Action</th>
                          </tr>
                      </thead>
                      <tbody>
                        <?php $sum_tot_Qty = 0 ?>
                    <?php $__empty_1 = true; $__currentLoopData = $getrecord; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                          <tr>
                              <td>
                                  <input class="delete-all-option" value="<?php echo e($value->id); ?>" type="checkbox" >
                                </td>
                              <td><?php echo e($value->id); ?></td>
                             
                              <td><?php echo e($value->sheet_no); ?></td> 
                              <td><?php echo e(date('d-m-yy', strtotime($value->product_date))); ?></td>
                              <td><?php echo e($value->location); ?></td>
                              <td><?php echo e($value->sub_location); ?></td>
                              <td><?php echo e($value->asset); ?></td>
                              <td><?php echo e($value->qty); ?></td>

                              <td>
                                
                                 <a href="<?php echo e(url('admin/product/edit/'.$value->id)); ?>" class="btn btn-success btn-rounded btn-sm"><span class="fa fa-pencil"></span></a> 
                        
                            

     						           <button class="btn btn-danger btn-rounded btn-sm" onClick="delete_record('<?php echo e(url('admin/product/delete/'.$value->id)); ?>');"><span class="fa fa-trash-o"></span></button> 
                   


                               <!-- MESSAGE BOX-->
     
                    <!-- END MESSAGE BOX-->    


                              </td>
                          </tr>
                          <?php $sum_tot_Qty += $value->qty ?>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                          <tr>
                              <td colspan="100%">Record not found.</td>

                          </tr>
                          <?php endif; ?>

                          <tr>
                          <th colspan="7"> Total Quantity</th>
                          <td>

                          <?php echo e($sum_tot_Qty); ?>

                        </td>

                         </tr>
                      </tbody>

                  </table>
                 <div style="float: right">
                   
                    
                    <?php echo e($getrecord->links()); ?> 
                
                  </div>
              </div>

              </div>
              
                    
                </div>
            </div>
        </div>


<?php $__env->stopSection(); ?>
  <?php $__env->startSection('script'); ?>
  <script type="text/javascript">
     $('.delete-all-option').change(function(){
        var total = '';
        $('.delete-all-option').each(function(){
            if(this.checked)
            {
                var id = $(this).val();
                total += id+',';
            }

        });

        var url = '<?php echo e(url('admin/product/delete_product_multi?id=')); ?>'+total;
        $('#getDeleteURL').attr('href',url);

        
    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\ivapp\resources\views/backend/product/list.blade.php ENDPATH**/ ?>