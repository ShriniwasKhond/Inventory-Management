
	
	<?php $__env->startSection('style'); ?>
	<style type="text/css">
		
	</style>
	<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

  <ul class="breadcrumb">
            <li><a href="">User</a></li>
            <li><a href="">Add User</a></li>
        </ul>
        
        <div class="page-title">                    
            <h2><span class="fa fa-arrow-circle-o-left"></span> Add User</h2>
        </div>

         <div class="page-content-wrap">
            <div class="row">
                <div class="col-md-12">
                    
                       <form class="form-horizontal" method="post" action="<?php echo e(url('admin/user/add')); ?>" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h3 class="panel-title"> Add User</h3>
                                </div>
                                <div class="panel-body">
                                
                                 <div class="form-group">
                                  <label class="col-md-3 col-xs-12 control-label">Name <span style="color:red"> *</span></label>
                                      <div class="col-md-7 col-xs-12">
                                          <div class="">
                                              <input name="name" value="<?php echo e(old('name')); ?>" placeholder="Name" maxlength="50" type="text" required class="form-control" />
                                              <span style="color:red"><?php echo e($errors->first('name')); ?></span>
                                          </div>
                                      </div>
                                  </div>

                                  
                                  <div class="form-group">
                                  <label class="col-md-3 col-xs-12 control-label">Email ID<span style="color:red"> *</span></label>
                                      <div class="col-md-7 col-xs-12">
                                          <div class="">
                                              <input name="email" value="<?php echo e(old('email')); ?>" required placeholder="Email ID" type="email" class="form-control" />
                                              <span style="color:red"><?php echo e($errors->first('email')); ?></span>
                                          </div>
                                      </div>
                                  </div>

                                  <div class="form-group">
                                   <label class="col-md-3 col-xs-12 control-label">Password <span style="color:red"> *</span></label>
                                    <div class="col-md-7 col-xs-12">
                                        <div class="">
                                            <input name="password" value="" placeholder="Password" type="text" required class="form-control" />
                                            <span style="color:red"><?php echo e($errors->first('password')); ?></span>
                                        </div>
                                    </div>
                                   </div>

                                   
                              


                                </div>
                                <div class="panel-footer">
                                    <button class="btn btn-primary pull-right">Submit</button>
                                </div>
                            </div>
                        </form>
                    
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>
  <?php $__env->startSection('script'); ?>
  <script type="text/javascript">
   
  </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\ivapp\resources\views/backend/user/add.blade.php ENDPATH**/ ?>