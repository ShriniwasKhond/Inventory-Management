  <div class="page-sidebar">

        <ul class="x-navigation">
            

            <li class="" style="background: #F85F6A; text-align: center;">
                <a style="font-size: 22px;" href="<?php echo e(url('admin/dashboard')); ?>"><b>IVApp</b></a>
                <a href="#" class="x-navigation-control"></a>
            </li>

            <li class="<?php if( Request::segment(2) == 'dashboard'): ?> active <?php endif; ?>">
                <a href="<?php echo e(url('admin/dashboard')); ?>"><span class="fa fa-desktop"></span> <span class="xn-text">Dashboard</span></a>
            </li>

            <li class="<?php if( Request::segment(2) == 'user'): ?> active <?php endif; ?>">
                <a href="<?php echo e(url('admin/user')); ?>"><span class="fa fa-user"></span> <span class="xn-text">User List</span></a>
            </li>

             <li class="<?php if( Request::segment(2) == 'product'): ?> active <?php endif; ?>">
                <a href="<?php echo e(url('admin/product')); ?>"><span class="fa fa-file-excel-o"></span> <span class="xn-text">Product List</span></a>
            </li>

        </ul>
    </div><?php /**PATH D:\xampp\htdocs\laravel\ivapp\resources\views/backend/layouts/_sidebar.blade.php ENDPATH**/ ?>