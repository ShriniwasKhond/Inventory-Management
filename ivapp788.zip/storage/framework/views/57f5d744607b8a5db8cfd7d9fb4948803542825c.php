
	
	<?php $__env->startSection('style'); ?>
	<style type="text/css">
		
	</style>
	<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

  <ul class="breadcrumb">
            <li><a href="">Product</a></li>
            <li><a href="">Add Product</a></li>
        </ul>
        
        <div class="page-title">                    
            <h2><span class="fa fa-arrow-circle-o-left"></span> Add Product</h2>
        </div>

         <div class="page-content-wrap">
            <div class="row">
                <div class="col-md-12">
                    
                       <form class="form-horizontal" method="post" action="<?php echo e(url('admin/product/add')); ?>" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h3 class="panel-title"> Add Product</h3>
                                </div>
                                <div class="panel-body">
                                
                                 <div class="form-group">
                                  <label class="col-md-3 col-xs-12 control-label">Sheet No <span style="color:red"> *</span></label>
                                      <div class="col-md-7 col-xs-12">
                                          <div class="">
                                              <input name="sheet_no" value="<?php echo e(old('sheet_no')); ?>" placeholder="Sheet No" maxlength="50" type="number" required class="form-control" />
                                              <span style="color:red"><?php echo e($errors->first('sheet_no')); ?></span>
                                          </div>
                                      </div>
                                  </div>

                                    <div class="form-group">
                                  <label class="col-md-3 col-xs-12 control-label">Date <span style="color:red"> *</span></label>
                                      <div class="col-md-7 col-xs-12">
                                          <div class="">
                                              <input name="product_date" value="<?php echo e(old('product_date')); ?>" placeholder="Date" type="date" required class="form-control" />
                                              <span style="color:red"><?php echo e($errors->first('product_date')); ?></span>
                                          </div>
                                      </div>
                                  </div>
                                  
                       

                                <div class="form-group">
                                  <label class="col-md-3 col-xs-12 control-label">Location <span style="color:red"> *</span></label>
                                      <div class="col-md-7 col-xs-12">
                                          <div class="">
                                              <input name="location" value="<?php echo e(old('location')); ?>" placeholder="Location" maxlength="100" type="text" required class="form-control" />
                                              <span style="color:red"><?php echo e($errors->first('location')); ?></span>
                                          </div>
                                      </div>
                                  </div>

                                 <div class="form-group">
                                  <label class="col-md-3 col-xs-12 control-label">Sub Location <span style="color:red"> *</span></label>
                                      <div class="col-md-7 col-xs-12">
                                          <div class="">
                                              <input name="sub_location" value="<?php echo e(old('sub_location')); ?>" placeholder="Sub Location" maxlength="100" type="text" required class="form-control" />
                                              <span style="color:red"><?php echo e($errors->first('sub_location')); ?></span>
                                          </div>
                                      </div>
                                  </div>
                              

                                <div class="form-group">
                                  <label class="col-md-3 col-xs-12 control-label">Asset <span style="color:red"> *</span></label>
                                      <div class="col-md-7 col-xs-12">
                                          <div class="">
                                              <input name="asset" value="<?php echo e(old('asset')); ?>" placeholder="Asset" maxlength="250" type="text" required class="form-control" />
                                              <span style="color:red"><?php echo e($errors->first('asset')); ?></span>
                                          </div>
                                      </div>
                                  </div>

                                <div class="form-group">
                                  <label class="col-md-3 col-xs-12 control-label">Qty <span style="color:red"> *</span></label>
                                      <div class="col-md-7 col-xs-12">
                                          <div class="">
                                              <input name="qty" value="<?php echo e(old('qty')); ?>" placeholder="Qty" maxlength="50" type="number" required class="form-control" />
                                              <span style="color:red"><?php echo e($errors->first('qty')); ?></span>
                                          </div>
                                      </div>
                                  </div>

                                </div>
                                <div class="panel-footer">
                                    <button class="btn btn-primary pull-right">Submit</button>
                                </div>
                            </div>
                        </form>
                    
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>
  <?php $__env->startSection('script'); ?>
  <script type="text/javascript">
   
  </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laravel\ivapp\resources\views/backend/product/add.blade.php ENDPATH**/ ?>