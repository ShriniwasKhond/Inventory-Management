<?php

namespace App\Http\Controllers\Backend;
// use App\Models\UsersModel;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Product;
use App\Models\ProductHistory;
use DB;

class DashboardController extends Controller
{
	public function dashboard_index(Request $request)
	{	

		$data['getProductCategoryA'] = Product::getProductCategoryA($request);
		$data['getProductCategoryB'] = Product::getProductCategoryB($request);
		$data['getProductCategoryC'] = Product::getProductCategoryC($request);
		$data['getProductQTYTotal'] = Product::getProductQTYTotal($request);
		
		$data['getProductQTYAvailableQtyA'] = ProductHistory::getProductQTYAvailableQtyA($request);
		$data['getProductQTYAvailableQtyB'] = ProductHistory::getProductQTYAvailableQtyB($request);
		$data['getProductQTYAvailableQtyC'] = ProductHistory::getProductQTYAvailableQtyC($request);
		$data['getProductQTYAvailableQtyTotal'] = ProductHistory::getProductQTYAvailableQtyTotal($request);

		$data['getGroupByUserID'] = ProductHistory::select('product_history.user_id','users.name', 		DB::raw('sum(product_history.available_qty) as total_qty'), DB::raw('count(*) as user_id_total'))
				->join('users', 'users.id', '=', 'product_history.user_id')
             	->groupBy('product_history.user_id')
                ->get();
		//dd($data['getGroupByUserID']);
		$data['meta_title'] = 'Dashboard List';
		return view('backend.dashboard.list', $data);
	}

}

?>